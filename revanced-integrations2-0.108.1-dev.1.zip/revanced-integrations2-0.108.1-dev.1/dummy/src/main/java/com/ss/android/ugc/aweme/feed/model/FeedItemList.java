package com.ss.android.ugc.aweme.feed.model;

import java.util.List;

//Dummy class
public class FeedItemList {
    public List<Aweme> items;
}
