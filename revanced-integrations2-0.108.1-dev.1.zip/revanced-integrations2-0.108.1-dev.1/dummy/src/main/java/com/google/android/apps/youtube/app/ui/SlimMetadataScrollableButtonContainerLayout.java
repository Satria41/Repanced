package com.google.android.apps.youtube.app.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;

public class SlimMetadataScrollableButtonContainerLayout extends ViewGroup {

    public SlimMetadataScrollableButtonContainerLayout(Context context) {
        super(context);
    }

    public SlimMetadataScrollableButtonContainerLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SlimMetadataScrollableButtonContainerLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onLayout(boolean b, int i, int i1, int i2, int i3) {

    }
}
