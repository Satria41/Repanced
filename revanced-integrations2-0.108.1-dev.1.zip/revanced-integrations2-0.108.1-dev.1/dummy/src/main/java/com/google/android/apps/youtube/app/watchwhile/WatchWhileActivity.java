package com.google.android.apps.youtube.app.watchwhile;

import android.app.Activity;

// Dummy class
public final class WatchWhileActivity extends Activity { }

