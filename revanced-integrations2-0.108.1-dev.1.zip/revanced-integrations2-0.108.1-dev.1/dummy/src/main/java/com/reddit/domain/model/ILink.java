package com.reddit.domain.model;

public class ILink {
    public boolean getPromoted() {
        throw new UnsupportedOperationException("Stub");
    }
}
