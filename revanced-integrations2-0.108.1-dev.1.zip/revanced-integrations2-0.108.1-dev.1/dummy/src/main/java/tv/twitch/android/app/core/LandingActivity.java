package tv.twitch.android.app.core;

import android.app.Activity;

public class LandingActivity extends Activity {}
