package tv.twitch.android.settings;

import android.app.Activity;

public class SettingsActivity extends Activity {}
